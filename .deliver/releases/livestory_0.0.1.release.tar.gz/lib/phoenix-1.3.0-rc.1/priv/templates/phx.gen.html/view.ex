defmodule <%= inspect context.web_module %>.<%= inspect schema.alias %>View do
  use <%= inspect context.web_module %>, :view
end
